from typing import Callable
from torch.utils.data.dataloader import DataLoader
from concrete.ml.torch.compile import compile_brevitas_qat_model

def fhe_compatibility(model: Callable, data: DataLoader) -> Callable:
    """Test if the model is FHE-compatible.

    Args:
        model (Callable): The Brevitas model.
        data (DataLoader): The data loader.

    Returns:
        Callable: Quantized model.
    """

    state_size = data.shape[1] * data.shape[2]
    data_reshaped = data.view(-1, state_size).to(data.device)

    qmodel = compile_brevitas_qat_model(
        model.actor.to("cpu"),
        # Training
        torch_inputset=data_reshaped,
        show_mlir=False,
        output_onnx_file="test.onnx",
    )

    return qmodel